/*
 * Copyright (c) 2005
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*
 * @author Last modified by $Author: jeffsh $
 * @version $Revision: 1.7 $ on $Date: 2005/10/17 18:49:45 $
 * @since Dec 13, 2004
 * 
 * Simple JOpt usage example
 * 
 * MAX 2X + 2Y
 * subject to
 * X - 2Y <= 5
 * Y = 2
 * 
 */
package edu.harvard.econcs.jopt.example;

import java.util.Map;

import edu.harvard.econcs.jopt.solver.IMIP;
import edu.harvard.econcs.jopt.solver.IMIPResult;
import edu.harvard.econcs.jopt.solver.client.SolverClient;
import edu.harvard.econcs.jopt.solver.mip.CompareType;
import edu.harvard.econcs.jopt.solver.mip.Constraint;
import edu.harvard.econcs.jopt.solver.mip.MIP;
import edu.harvard.econcs.jopt.solver.mip.Term;
import edu.harvard.econcs.jopt.solver.mip.VarType;
import edu.harvard.econcs.jopt.solver.mip.Variable;

/**
 * A simple example of how to use JOpt
 * 
 * @author Last modified by $Author: jeffsh $
 * @version $Revision: 1.7 $ on $Date: 2005/10/17 18:49:45 $
 *
 **/
public class ExampleSimple {

    /**
     * First we construct the mip formulation that we wish to solve. In this example,
     * it is actually an LP. Later in this file, we put different constraints into the
     * MIP. Constraints are filled with Terms. Terms are filled with a Variable and a
     * coefficient on the variable.
     */
    private IMIP mip = new MIP();
    
    /**
     * After the call to solve, result will hold the results of the solver, such as the
     * objective value and values of individual variables, and the dual, etc.
     */
    private IMIPResult result;
    
    /**
     * All constraints should have a unique id so that their dual can be examined.
     */
    static int constraintID = 0;
    
    /** 
     * MAX 2X + 2Y
     * subject to
     * X - 2Y <= 5
     * Y = 2
     * @param serverMachine the friendly-name or IP address of the server machine
     * @param serverPort the port on the server where JOpt-server is listening
     */
    
    public ExampleSimple(String serverMachine, int serverPort) {

		/** If you wanted to use a remote solver, you would do something like: */
		SolverClient solverClient = new SolverClient(serverMachine, serverPort);
		
		/** If you want to use the locally installed CPLEX server (avoids RMI), do something like: */
		//SolverClient solverClient = new SolverClient();
		
    	/** Create two variables, x and y, which are doubles that can range from -INF to INF
    	 * and add them to the MIP.
    	 */
    	
    	Variable x = new Variable("x", VarType.DOUBLE, -1*MIP.MAX_VALUE, MIP.MAX_VALUE);
        Variable y = new Variable("y", VarType.DOUBLE, -1*MIP.MAX_VALUE, MIP.MAX_VALUE);
        
        mip.add(x);
        mip.add(y);
        
        /**
         * We MAX in our objective function. Alternate: setObjectiveMax(false) will MIN.
         */
        mip.setObjectiveMax(true);
        mip.addObjectiveTerm(new Term(x, 2));
        mip.addObjectiveTerm(new Term(y, 2));

        /**
         * Create a new constraint, showing off two ways to make a term.
         * X - 2Y <= 5
         */        
        
        Constraint c1 = new Constraint(CompareType.LEQ, 5);
        c1.addTerm(new Term(x, 1.0));
        c1.addTerm(y, -2);
        mip.add(c1, constraintID++);

        /**
         * Create a new constraint.
         * Y == 2
         */        
         
        Constraint c2 = new Constraint(CompareType.EQ, 2);
        c2.addTerm(new Term(y, 1.0));
        mip.add(c2, constraintID++);        
        
        /** 
         * Demonstrate how we can write out a mip or a constraint (or a term/variable)
         * for debugging output.
         */
        System.out.println(mip.toString());
        System.out.println(c2.toString());
        
        /**
         * Solve the MIP
         */
        
        result = solverClient.solve(mip);
                
        /**
         * Get the objective value (should be 22) and the values of the variables.
         */
        
        double objective = result.getObjectiveValue();
        Map m = result.getValues();
        
        System.out.println("objective: " + objective);
        System.out.println("x is " + m.get("x"));
        System.out.println("y is " + m.get("y"));
    }
    
    public static void main(String[] args) {
		if (args.length < 2) {
			System.out.println("Usage: java edu.harvard.econcs.jopt.example.ExampleSimple ServerHostName ServerPortNumber");
			System.exit(-1);
		}
        new ExampleSimple(args[0], new Integer(args[1]).intValue());
    }

}
